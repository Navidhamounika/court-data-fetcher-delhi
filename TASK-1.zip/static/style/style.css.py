/* Reset some defaults */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, Helvetica, sans-serif;
    background-color: #f4f6f8;
    color: #333;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

/* Header */
header {
    background-color: #1e3d59;
    color: white;
    padding: 1rem;
    text-align: center;
    font-size: 1.5rem;
}

/* Form container */
form {
    background: white;
    padding: 2rem;
    max-width: 600px;
    margin: 2rem auto;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

form label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: bold;
}

form select,
form input,
form button {
    width: 100%;
    padding: 0.7rem;
    margin-bottom: 1rem;
    border: 1px solid #ccc;
    border-radius: 4px;
}

form button {
    background-color: #1e3d59;
    color: white;
    font-size: 1rem;
    cursor: pointer;
    border: none;
    transition: background 0.3s ease;
}

form button:hover {
    background-color: #145388;
}

/* Results section */
.results {
    background: white;
    max-width: 900px;
    margin: 2rem auto;
    padding: 1.5rem;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.results h2 {
    margin-bottom: 1rem;
    color: #1e3d59;
}

.results table {
    width: 100%;
    border-collapse: collapse;
}

.results th,
.results td {
    padding: 0.8rem;
    border-bottom: 1px solid #ddd;
    text-align: left;
}

.results th {
    background-color: #f0f0f0;
}

/* Footer */
footer {
    margin-top: auto;
    text-align: center;
    padding: 1rem;
    font-size: 0.9rem;
    background-color: #1e3d59;
    color: white;
}
