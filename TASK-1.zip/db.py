# db.py
import sqlite3, json, os

SCHEMA = """
CREATE TABLE IF NOT EXISTS queries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    case_type TEXT,
    case_no TEXT,
    filing_year TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS raw_responses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    query_id INTEGER,
    html TEXT,
    fetched_at TEXT,
    FOREIGN KEY(query_id) REFERENCES queries(id)
);
CREATE TABLE IF NOT EXISTS cases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    query_id INTEGER,
    parsed_json TEXT,
    saved_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(query_id) REFERENCES queries(id)
);
"""

def init_db(db_path):
    os.makedirs(os.path.dirname(db_path), exist_ok=True) if os.path.dirname(db_path) else None
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.executescript(SCHEMA)
    conn.commit()
    conn.close()

def log_query(db_path, case_type, case_no, filing_year):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO queries (case_type, case_no, filing_year) VALUES (?, ?, ?)",
        (case_type, case_no, filing_year)
    )
    qid = cur.lastrowid
    conn.commit()
    conn.close()
    return qid

def save_parsed_case(db_path, query_id, parsed, raw_meta):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("INSERT INTO raw_responses (query_id, html, fetched_at) VALUES (?, ?, ?)",
                (query_id, raw_meta.get("html",""), raw_meta.get("fetched_at","")))
    cur.execute("INSERT INTO cases (query_id, parsed_json) VALUES (?, ?)",
                (query_id, json.dumps(parsed)))
    conn.commit()
    conn.close()
