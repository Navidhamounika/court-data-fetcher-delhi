# app.py
import os
import json
from flask import Flask, request, render_template, redirect, url_for, flash
from db import init_db, log_query, save_parsed_case
from scraper import fetch_case_details, ScraperError
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__, static_folder="static")
app.secret_key = os.environ.get("FLASK_SECRET", "dev-secret")

DB_PATH = os.path.join(os.path.dirname(__file__), "courtdata.db")
init_db(DB_PATH)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/query", methods=["POST"])
def query():
    case_type = request.form.get("case_type", "").strip()
    case_no = request.form.get("case_no", "").strip()
    filing_year = request.form.get("filing_year", "").strip()
    manual_captcha = request.form.get("manual_captcha", "").strip() or None

    if not (case_type and case_no and filing_year):
        flash("Please fill all fields.", "warning")
        return redirect(url_for("index"))

    qid = log_query(DB_PATH, case_type, case_no, filing_year)
    try:
        parsed, raw_meta = fetch_case_details(case_type, case_no, filing_year, manual_captcha=manual_captcha)
    except ScraperError as e:
        flash(f"Scraper error: {e}", "danger")
        return redirect(url_for("index"))
    except Exception as e:
        flash(f"Unexpected error: {e}", "danger")
        return redirect(url_for("index"))

    save_parsed_case(DB_PATH, qid, parsed, raw_meta)
    return render_template("results.html", parsed=parsed, raw_meta=raw_meta)

if __name__ == "__main__":
    debug = os.environ.get("FLASK_ENV", "development") == "development"
    app.run(host="0.0.0.0", port=5000, debug=debug)
