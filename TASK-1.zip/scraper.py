# scraper.py
import os, time, json
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
from datetime import datetime

BASE_SITE = "https://delhihighcourt.nic.in/"  # declared target; change if you pick another court

class ScraperError(Exception):
    pass

def _now_utc():
    return datetime.utcnow().isoformat() + "Z"

def fetch_case_details(case_type, case_no, filing_year, manual_captcha=None, timeout=20000):
    """
    Uses Playwright to navigate the court site, perform a case search and parse results.

    Returns: (parsed_dict, raw_meta)
    parsed_dict fields:
      - case_number
      - parties (list)
      - filing_date
      - next_hearing
      - orders (list of {title, pdf})
    raw_meta:
      - html, fetched_at

    NOTE: CSS / XPATH selectors below are **placeholders** and must be adapted after inspecting the target site's DOM.
    """
    with sync_playwright() as p:
        headless = os.environ.get("PLAYWRIGHT_HEADLESS", "true").lower() == "true"
        browser = p.chromium.launch(headless=headless)
        page = browser.new_page()

        try:
            page.goto(BASE_SITE, timeout=timeout)
        except PWTimeout:
            browser.close()
            raise ScraperError("Timed out loading base site. Site may be down or blocked.")

        # === Example navigation flow (update selectors to match actual court site) ===
        try:
            # Example: click "Case Status" or "Cause List" link if needed
            # If the site exposes a direct search page, navigate to it:
            # page.click("text=Case Status")
            # page.wait_for_load_state("networkidle", timeout=timeout)

            # Attempt to find search form fields (selectors below are placeholders)
            # Replace '#caseNumber' etc. with actual selectors found via browser devtools.
            # 1) Fill case number & year & type
            # Try a list of candidate selectors to be resilient
            selectors_case_no = ["input#caseNo", "input[name='caseNo']", "input[id*='CaseNumber']"]
            sel_case_no = None
            for s in selectors_case_no:
                try:
                    if page.query_selector(s):
                        sel_case_no = s
                        break
                except:
                    pass
            if sel_case_no is None:
                # if no case input found, try performing a generic text search approach
                # In many eCourts portals, there's a common search form — otherwise we fail early.
                raise ScraperError("Could not locate case-number input on the page — update scraper selectors.")

            page.fill(sel_case_no, str(case_no))

            # Filing year
            selectors_year = ["input#year", "input[name='year']", "select#year"]
            sel_year = None
            for s in selectors_year:
                if page.query_selector(s):
                    sel_year = s
                    break
            if sel_year:
                # if it's a select, choose; else fill
                tag = page.query_selector(sel_year).eval_on_selector("self", "el => el.tagName")
                if tag.lower() == "select":
                    page.select_option(sel_year, str(filing_year))
                else:
                    page.fill(sel_year, str(filing_year))

            # Case type (if present)
            selectors_type = ["select#caseType", "select[name='caseType']", "input[name='caseType']"]
            for s in selectors_type:
                if page.query_selector(s):
                    try:
                        page.select_option(s, case_type)
                    except:
                        try:
                            page.fill(s, case_type)
                        except:
                            pass
                    break

            # Some sites show CAPTCHA - detect common captcha elements
            if page.query_selector("input#captcha") or page.query_selector("input[name='captcha']") or page.query_selector("div.g-recaptcha"):
                if not manual_captcha:
                    browser.close()
                    raise ScraperError("CAPTCHA detected. Provide manual captcha response in the UI or set up a solver.")
                # if manual provided, fill it
                if page.query_selector("input#captcha"):
                    page.fill("input#captcha", manual_captcha)

            # Click search button (try several candidate selectors)
            clicked = False
            for btn_sel in ["button#search", "button[type='submit']", "input[type='submit']", "text=Search"]:
                try:
                    el = page.query_selector(btn_sel)
                    if el:
                        el.click()
                        clicked = True
                        break
                except:
                    continue
            if not clicked:
                # fallback: press Enter in the case_no field
                page.focus(sel_case_no)
                page.keyboard.press("Enter")

            # Wait for results to appear
            # Candidate: a results table row, or a case details block
            possible_result_selectors = [".case-details", ".result-row", "table#result_table", "div#content"]
            found = False
            for rs in possible_result_selectors:
                try:
                    if page.wait_for_selector(rs, timeout=5000):
                        found = True
                        break
                except:
                    continue
            if not found:
                # Try to capture the current page for debugging
                html_debug = page.content()
                browser.close()
                raise ScraperError("No results detected after search — site layout may differ. Save html for inspection.\n\n" + html_debug[:1000])

            # === Parsing ===
            html = page.content()
            parsed = {}
            parsed['case_number'] = f"{case_type} {case_no}/{filing_year}"
            # Parties: attempt to gather text from likely selectors
            parties = []
            for party_sel in [".party-name", ".party", "td.party", "div.parties", "label:has-text('Parties') + div"]:
                try:
                    nodes = page.query_selector_all(party_sel)
                    if nodes:
                        for n in nodes:
                            text = n.inner_text().strip()
                            if text and text not in parties:
                                parties.append(text)
                except:
                    pass
            parsed['parties'] = parties

            # Filing date & next hearing — try several selectors
            def pick_text(cands):
                for c in cands:
                    try:
                        el = page.query_selector(c)
                        if el:
                            t = el.inner_text().strip()
                            if t:
                                return t
                    except:
                        pass
                return None

            parsed['filing_date'] = pick_text([".filing-date", "td:has-text('Filing Date') + td", "text=Filing Date"])
            parsed['next_hearing'] = pick_text([".next-hearing", "td:has-text('Next Hearing') + td", "text=Next Hearing"])

            # Orders / judgments — collect most recent PDF links
            orders = []
            # detect all anchors linking to pdfs
            anchors = page.query_selector_all("a")
            for a in anchors:
                try:
                    href = a.get_attribute("href") or ""
                    text = a.inner_text().strip() or href
                    if href.lower().endswith(".pdf") or ".pdf" in href.lower():
                        # Normalize relative links
                        if href.startswith("/"):
                            from urllib.parse import urljoin
                            href = urljoin(page.url, href)
                        orders.append({"title": text, "pdf": href})
                except:
                    continue
            # Deduplicate and sort (most recent first if dates in title)
            uniq = []
            seen = set()
            for o in orders:
                if o['pdf'] not in seen:
                    uniq.append(o)
                    seen.add(o['pdf'])
            parsed['orders'] = uniq

            raw_meta = {"html": html, "fetched_at": _now_utc(), "url": page.url}
            browser.close()
            return parsed, raw_meta

        except PWTimeout:
            browser.close()
            raise ScraperError("Timeout while searching or parsing the page.")
        except ScraperError:
            browser.close()
            raise
        except Exception as e:
            browser.close()
            raise Scraper
