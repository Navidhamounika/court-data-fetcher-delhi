# readme.md.py
# This script creates a README.md file for the Court-Data Fetcher & Mini-Dashboard project

readme_content = """
# Court-Data Fetcher & Mini-Dashboard

## 📌 Overview
This project is a **web-based tool** that allows users to fetch **case metadata** and **latest orders/judgments** from the **Delhi High Court** website.  

It is built with:
- **Python (Flask)** for the backend
- **HTML, CSS, JavaScript** for the frontend
- **BeautifulSoup4** for web scraping
- **SQLite** for local storage
- **Docker** for containerized deployment

---

## 🚀 Features
- Choose **Case Type**, **Case Number**, and **Year**
- Fetch case details from the Delhi High Court
- Display results in a clean dashboard
- Save search results in a database
- Run locally or in Docker

---

## 🛠️ Tech Stack
- **Backend:** Python 3.11, Flask
- **Frontend:** HTML, CSS, JavaScript
- **Scraping:** BeautifulSoup4, Requests
- **Database:** SQLite
- **Containerization:** Docker

---

## 📂 Project Structure




