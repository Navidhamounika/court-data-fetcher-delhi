<!-- templates/results.html -->
<!doctype html>
<html>
  <head><title>Case Results</title></head>
  <body>
    <h1>Results</h1>
    <h3>Case: {{ parsed.case_number }}</h3>
    <p><strong>Parties:</strong></p>
    <ul>
      {% for p in parsed.parties %}<li>{{p}}</li>{% endfor %}
    </ul>
    <p><strong>Filing Date:</strong> {{ parsed.filing_date }}</p>
    <p><strong>Next Hearing:</strong> {{ parsed.next_hearing }}</p>

    <h3>Orders / Judgments</h3>
    <ul>
      {% for o in parsed.orders %}
        <li>{{ o.title }} - <a href="/download_pdf?url={{ o.pdf }}">Download PDF</a></li>
      {% else %}
        <li>No orders found.</li>
      {% endfor %}
    </ul>

    <h4>Raw meta</h4>
    <pre style="max-height:200px; overflow:auto;">{{ raw_meta.fetched_at }}</pre>

    <p><a href="/">Back</a></p>
  </body>
</html>
