<!-- templates/index.html -->
<!doctype html>
<html>
  <head><title>Court Data Fetcher</title></head>
  <body>
    <h1>Delhi High Court — Case Lookup</h1>
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% if messages %}
        <ul>
          {% for category, msg in messages %}<li>{{msg}}</li>{% endfor %}
        </ul>
      {% endif %}
    {% endwith %}
    <form action="/query" method="post">
      <label>Case Type:
        <select name="case_type">
          <option value="CIVIL">Civil</option>
          <option value="CRIMINAL">Criminal</option>
        </select>
      </label><br>
      <label>Case Number: <input name="case_no" required></label><br>
      <label>Filing Year: <input name="filing_year" required></label><br>
      <button type="submit">Search</button>
    </form>
  </body>
</html>
