Flask==2.2.5
playwright==1.40.0
sqlalchemy==2.0.20
python-dotenv==1.0.0
requests==2.31.0
