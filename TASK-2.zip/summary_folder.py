from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
from google.oauth2 import service_account
import openai
import tempfile

SERVICE_ACCOUNT_FILE = "google_service_account.json"
SCOPES = ['https://www.googleapis.com/auth/drive']
creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
drive_service = build('drive', 'v3', credentials=creds)

# OpenAI API key
openai.api_key = "YOUR_OPENAI_KEY"

def summarise_folder(folder_name):
    # Get folder ID
    query = f"name = '{folder_name}' and mimeType = 'application/vnd.google-apps.folder'"
    folder = drive_service.files().list(q=query, fields="files(id)").execute().get('files', [])
    if not folder:
        return f"Folder '{folder_name}' not found."
    folder_id = folder[0]['id']

    # Get files
    files = drive_service.files().list(
        q=f"'{folder_id}' in parents and (mimeType contains 'text' or mimeType contains 'pdf')",
        fields="files(id, name)"
    ).execute().get('files', [])

    if not files:
        return "No readable files found."

    summaries = []
    for f in files:
        temp_path = tempfile.mktemp()
        request = drive_service.files().get_media(fileId=f['id'])
        with open(temp_path, 'wb') as fh:
            downloader = MediaIoBaseDownload(fh, request)
            done = False
            while not done:
                status, done = downloader.next_chunk()

        try:
            with open(temp_path, "r", errors="ignore") as file_data:
                content = file_data.read()

            response = openai.ChatCompletion.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": f"Summarise this:\n{content}"}],
                max_tokens=150
            )
            summary_text = response.choices[0].message['content']
            summaries.append(f"{f['name']}:\n{summary_text}")
        except:
            summaries.append(f"{f['name']}: Could not summarise.")

    return "\n\n".join(summaries)

if __name__ == "__main__":
    folder = input("Enter folder name: ")
    print(summarise_folder(folder))
